/*
function display() {
   var buttons0 = document.getElementById('zero').textContent;
    var i;
    for (i = 0; i < x.length; i++) {
    x[i].document.getElementById("screen").innerHTML = buttons;
    }

}

screen.addEventListener('button'); */


 function display_zero() {
    var buttons0 = document.getElementById('zero').textContent;
      document.getElementById("screen").innerHTML = buttons0
}

function display_one() {
   var buttons1 = document.getElementById('one').textContent;
     document.getElementById("screen").innerHTML = buttons1
}

function display_two() {
   var buttons2 = document.getElementById('two').textContent;
     document.getElementById("screen").innerHTML = buttons2
}


function display_three() {
   var buttons3 = document.getElementById('three').textContent;
     document.getElementById("screen").innerHTML = buttons3
}


function display_four() {
   var buttons4 = document.getElementById('four').textContent;
     document.getElementById("screen").innerHTML = buttons4
}


function display_five() {
   var buttons5 = document.getElementById('five').textContent;
     document.getElementById("screen").innerHTML = buttons5
}


function display_six() {
   var buttons6 = document.getElementById('six').textContent;
     document.getElementById("screen").innerHTML = buttons6
}


function display_seven() {
   var buttons7 = document.getElementById('seven').textContent;
     document.getElementById("screen").innerHTML = buttons7
}


function display_eight() {
   var buttons8 = document.getElementById('eight').textContent;
     document.getElementById("screen").innerHTML = buttons8
}


function display_nine() {
   var buttons9 = document.getElementById('nine').textContent;
     document.getElementById("screen").innerHTML = buttons9
}


function display_plus() {
   var buttons10 = document.getElementById('plus').textContent;
     document.getElementById("screen").innerHTML = buttons10
}


function display_minus() {
   var buttons12 = document.getElementById('minus').textContent;
     document.getElementById("screen").innerHTML = buttons12
}


function display_multiple() {
   var buttons13 = document.getElementById('multiple').textContent;
     document.getElementById("screen").innerHTML = buttons13
}


function display_divide() {
   var buttons14 = document.getElementById('divide').textContent;
     document.getElementById("screen").innerHTML = buttons14
}


function display_equal() {
   var buttons15 = document.getElementById('equal').textContent;
     document.getElementById("screen").innerHTML = buttons15
}


function display_cancel() {
   var buttons16 = document.getElementById('cancel').textContent;
     document.getElementById("screen").innerHTML = buttons16
}
