var op1 = null, op2 = null, operator = null;
var screen = document.getElementById('screen');


function clkNum() {
    var e = event.target;
        if(op1 == null && op2 == null && operator == null) {
            op1 = parseInt(event.target.textContent);
            screen.textContent = op1;
            console.log(op1);
        }
        //first number and operator are selected, second number is not selected
        else if(op1 != null&& operator != null && op2==null){
            op2= parseInt(event.target.textContent);
            screen.textContent= op2;
            console.log(op2);
        }
}



function clkOperator() {
    var e = event.target;
    if( op1 !=null && operator == null && e.textContent !='='){
        operator=event.target.textContent;
        console.log(operator);
    }
    if  (op1 !=null && op2 !=null && e.textContent == '='){
        calcuate();
    }
}



function calcuate() {
    if( operator == '+'){
        op1 = op1+op2;
    }

    else if( operator == '-'){
    op1 = op1-op2;
    }
    else if( operator == '*'){
    op1 = op1*op2;
    }
    else if( operator == '/'){
    op1 = op1/op2;
    }
    screen.textContent=op1;
    console.log("Answer =" + op1);
    operator=null;
    op2=null;
}



function clkReset() {
    op1 = null;
    op2 = null;
    operator = null;
    screen.textContent = 0;

}

document.getElementById('one').addEventListener('click', clkNum);
document.getElementById('two').addEventListener('click', clkNum);
document.getElementById('three').addEventListener('click', clkNum);
document.getElementById('four').addEventListener('click', clkNum);
document.getElementById('five').addEventListener('click', clkNum);
document.getElementById('six').addEventListener('click', clkNum);
document.getElementById('seven').addEventListener('click', clkNum);
document.getElementById('eight').addEventListener('click', clkNum);
document.getElementById('nine').addEventListener('click', clkNum);
document.getElementById('zero').addEventListener('click', clkNum);

document.getElementById('plus').addEventListener('click', clkOperator);
document.getElementById('cancel').addEventListener('click', clkReset);
document.getElementById('minus').addEventListener('click', clkOperator);
document.getElementById('multiple').addEventListener('click', clkOperator);
document.getElementById('divide').addEventListener('click', clkOperator);
document.getElementById('equal').addEventListener('click', clkOperator);
