console.log("Elements");
console.log(document.getElementById('c'));
console.log(document.getElementById('b').textContent);
console.log(document.getElementsByClassName('button')[3]);
console.log(document.getElementsByClassName('button')[0].textContent);
console.log(document.getElementsByTagName('div')[3]);
console.log(document.getElementsByTagName('div')[5].innerHTML);