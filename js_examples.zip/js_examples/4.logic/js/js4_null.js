/* S. Trowbridge 2019 */

/*
    Null

    Null is used to indicate that a variable has no value.

    Null
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null
*/

var a = null; // no value is set

function checkNull() {
    console.log(a);
    if(a == null) {         // check if a has no value
        event.target.textContent = "No Value";
        a = 1;
    }
    else if(a < 5) {
        event.target.textContent = a;        
        a++;
    }
    else if(a == 5) {
        event.target.textContent = a;    
        a = null;  
    }
}

document.getElementsByClassName('box')[0].addEventListener('click', checkNull);