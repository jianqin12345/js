/* S. Trowbridge 2019 */

/*
    NOT something yields the opposite boolean value.

    NOT
    A   !A  
    T   F
    F   T 
*/

var a = true, b = true;

function printNOT() {
    if(!a) { // a OR b
        console.log("!"+a+" = true");
    } else {
        console.log("!"+a+" = false");
    }
}

function toggle() {
    var e = event.target;
    // nested if (if/else inside an if/else)
    if(e.textContent == 'A') { // if event is button A
        if(a == true) {         // if var a is true
            e.setAttribute('class', 'box black');
            a = false;
        }
        else {                  // if var a is false
            e.setAttribute('class', 'box red');
            a = true;
        }
    }
    else {                      // if event is button B
        if(b == true) {         // if var b is true
            e.setAttribute('class', 'box black');
            b = false;
        }
        else {                  // if var b is false
            e.setAttribute('class', 'box red');
            b = true;
        }
    }
    printNOT();
}

document.getElementById('a').addEventListener('click', toggle);