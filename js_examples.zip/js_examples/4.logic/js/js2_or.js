/* S. Trowbridge 2019 */

/*
    OR is false only if a and b are false.

    OR
    A   B   A OR B
    T   T   T
    T   F   T
    F   T   T
    F   F   F
*/

var a = true, b = true;

function printOR() {
    if(a || b) { // a OR b
        console.log(a+" || "+b+" = true");
    } else {
        console.log(a+" || "+b+" = false");
    }
}

function toggle() {
    var e = event.target;
    // nested if (if/else inside an if/else)
    if(e.textContent == 'A') { // if event is button A
        if(a == true) {         // if var a is true
            e.setAttribute('class', 'box black');
            a = false;
        }
        else {                  // if var a is false
            e.setAttribute('class', 'box red');
            a = true;
        }
    }
    else {                      // if event is button B
        if(b == true) {         // if var b is true
            e.setAttribute('class', 'box black');
            b = false;
        }
        else {                  // if var b is false
            e.setAttribute('class', 'box red');
            b = true;
        }
    }
    printOR();
}

document.getElementById('a').addEventListener('click', toggle);
document.getElementById('b').addEventListener('click', toggle);