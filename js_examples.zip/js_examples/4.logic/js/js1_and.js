/* S. Trowbridge 2019 */

/*
    AND is true only if a and b are true.

    AND
    A   B   A AND B
    T   T   T
    T   F   F
    F   T   F
    F   F   F
*/

var a = true, b = true;

function printAND() {
    if(a && b) { // a AND b
        console.log(a+" && "+b+" = true");
    } else {
        console.log(a+" && "+b+" = false");
    }
}

function toggle() {
    var e = event.target;
    // nested if (if/else inside an if/else)
    if(e.textContent == 'A') { // if event is button A
        if(a == true) {         // if var a is true
            e.setAttribute('class', 'box black');
            a = false;
        }
        else {                  // if var a is false
            e.setAttribute('class', 'box red');
            a = true;
        }
    }
    else {                      // if event is button B
        if(b == true) {         // if var b is true
            e.setAttribute('class', 'box black');
            b = false;
        }
        else {                  // if var b is false
            e.setAttribute('class', 'box red');
            b = true;
        }
    }
    printAND();
}

document.getElementById('a').addEventListener('click', toggle);
document.getElementById('b').addEventListener('click', toggle);