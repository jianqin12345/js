/* S. Trowbridge 2019 */

/*
    Array

    An array is a group of variables identified by a single name. 

    Syntax to create an array:
    var letters = ['A', 'B', 'C', 'D'];
    var numbers = [1, 2, 3, 4];

    Syntax to acces an array element:
    letters[5] = 'D';           // sets D to the 6th element in the array (index 5)
    console.log(numbers[2]);    // outputs the 3rd element in the array (index 2)

    Array
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array

*/

// boxes is an "array" of box elements, divs is an array of div elements
var boxes = document.getElementsByClassName('box');
var dives = document.getElementsByTagName('div');    

// create various arrays
var numbers  = [1, 2, 3, 4, 5, 6, 7, 8, 9];  
var letters = ['A', 'B', 'C', 'D', 'E', 'F'];
var symbols = ['!', '@', '#']; 
var categories = ['letters','numbers','symbols', 'sizes']; 
                
// assign each box to an array value from the array categories
boxes[0].textContent = categories[0];                      
boxes[1].textContent = categories[1];
boxes[2].textContent = categories[2];
boxes[3].textContent = categories[3];

// functions which output the values of three different arrays
function printNumbers() {
    console.log(numbers[0]);
    console.log(numbers[1]);
    console.log(numbers[2]);
    console.log(numbers[3]); 
    console.log(numbers[4]);
    console.log(numbers[5]);
    console.log(numbers[6]);
    console.log(numbers[7]);     
    console.log(numbers[8]);    
    console.log("");            
}
function printLetters() {
    console.log(letters[0]);
    console.log(letters[1]);
    console.log(letters[2]);
    console.log(letters[3]);
    console.log(letters[4]);
    console.log(letters[5]);   
    console.log("");             
}
function printSymbols() {
    console.log(symbols[0]);
    console.log(symbols[1]);
    console.log(symbols[2]);
    console.log("");   
}
function printSizes() {
    console.log(numbers.length);
    console.log(letters.length);
    console.log(symbols.length);        
}

// assign a listener to call a different function for each button
boxes[0].addEventListener('click', printNumbers);
boxes[1].addEventListener('click', printLetters);
boxes[2].addEventListener('click', printSymbols);
boxes[3].addEventListener('click', printSizes);

