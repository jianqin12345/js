var screen = document.getElementById('screen');           // assign a variable to the screen of our inteface
var boxes = document.getElementsByClassName('box');       // assign boxes to the array of box class elements

var values = [0, 0, 0, 0];                                // create an array of four values (same size as boxes)

function clearScreen() {                                  // create an array of four values (same size as boxes)
    document.getElementById('screen').textContent = "";   // clear the screen area (set it equal to a blank string)
    for(i=0; i<boxes.length; i++) {                       // set each box textcontent equal to 0
        boxes[i].textContent = values[i];
    }
    console.log("clearScreen()");
}
function incVal() {                                       // increment the value of a box from 0 up to 9, then reset to 0
    var box = event.target;                               // set the variable box to the box element
    if( box.textContent == 9 ) {                          // if box text content is equal to 9    
        box.textContent = 0;                              // reset it to 0
    }
    else {                                                // if box content is not equal to 9 (any other value) 
        box.textContent = box.textContent + 1;            // increment it by 1                           
    }
    console.log("incVal()");
}
function updateScreen() {                                 // update the screen to be the sum of all button values
    var sum = "";                                         // set initial sum value to an empty string
    for(i=0; i<boxes.length; i++) {                       // iterate through all boxes
        sum = sum + boxes[i].textContent;                 // update the sum by adding the current box value (repeat for all boxes)
    }
    screen.textContent = sum;                             // update the screen content with the new sum value
    console.log("updateScreen()");
}

for(i=0; i<boxes.length; i++) {                           // iterate from 0 to 3
    boxes[i].textContent = values[i];                     // populate each box with a value from the data array
    boxes[i].addEventListener('click', incVal);           // add an click event listener for each box that calls incVal    
    boxes[i].addEventListener('click', updateScreen);     // add an click event listener for each box that calls incVal    
}
screen.addEventListener('click', clearScreen);            // add a listener to clear screen if it is cliedk upon
updateScreen();                                           // call the updateScreen function when the document loads

