/* S. Trowbridge 2019 */

/*
    If/Else

    If something is true do X, else do Y. This is where a program decides what code to run based upon a condition.

    Syntax:
    if(condition) { // this specifies what code to run if the condition is true
        some code;
    } else {        // this specifies what code to run if the condition is false
        some other code;
    }

    If/Else
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/if...else

*/

var boxes = document.getElementsByClassName('box'); // assign boxes to the array of box class elements

function toggleValue() {
    var box = event.target;                         // the element associated with the event that trigged the function
    var text = event.target.textContent;            // the text content of the element

    if(text == 1) {                                 // if the content of the element is equal to 1, run the following code in the braces
        console.log( box.getAttribute('class') );   // print whatever classes are currently associated with the element box
        box.setAttribute('class', 'box red')        // change the class attribute of the box element (which classes are associated)
        box.textContent = 0;                        // set box content to 0
    } else {                                        // if the content of the element is NOT equal to 1, run the following code in the braces
        console.log( box.getAttribute('class') );   // print whatever classes are currently associated with the element box
        box.setAttribute('class', 'box green')      // change the class attribute of the box element (which classes are associated)       
        box.textContent = 1;                        // set box content to 1
    }
    console.log(box.textContent)                    // output the box that triggered the function call to console
}

boxes[0].addEventListener('click', toggleValue);
boxes[1].addEventListener('click', toggleValue);
boxes[2].addEventListener('click', toggleValue);
boxes[3].addEventListener('click', toggleValue);

