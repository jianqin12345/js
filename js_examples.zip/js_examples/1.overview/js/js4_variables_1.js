/* S. Trowbridge 2019 */

/*
    Variables
    Variables store information which can be retrieved for later use.

    Syntax:
    var variablename = data_to_store;

    JavaScript Guide
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

    Variable
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/var
*/

// store the elemnent HTMl code into a variable
var element_a = document.getElementById('a');
var element_b = document.getElementById('b');

// store the elemnent text content into a variable
var element_c = document.getElementById('c').textContent;
var element_d = document.getElementById('d').textContent;

// output the contents of each variable to the console using the variable names
console.log(element_a);
console.log(element_b);
console.log(element_c);
console.log(element_d);
console.log(element);    // this will print undefined, because the variable 'element' does not exist yet

// this statement must occur before the variable 'element' can be used
var element = document.getElementById('a'); 

// The following lines modify the original content from the HTML file
document.getElementById('c').textContent = 'Y';
document.getElementById('d').textContent = 'Z';

// Note that this prints the original values of the variable, because the variables were not updated
console.log(element_c);
console.log(element_d);

// However, directly accessing the elements again will print the updated values.
console.log( document.getElementById('c').textContent );
console.log( document.getElementById('d').textContent );