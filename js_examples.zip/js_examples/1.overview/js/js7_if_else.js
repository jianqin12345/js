/* S. Trowbridge 2019 */

/*
    Boolean Conditions

    Statements that result in true or false values.

    Equality Operator ==
    Given the expression a == b, this resolves to true if the value of a is equivalent to the value of b.
    Otherwise it resolves to false.

    Inequality Operator !=
    Given the expression a != b, this resolves to false if the value of a is equivalent to the value of b.
    Otherwise it resolves to true.

    Greater than, Less Than, Greater than or equal to, Less than or equal to (> < >= <=)
    All resolve to true or false.

    Boolean
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean

    Comparison Operators
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Comparison_Operators

*/

// assign the variable boxes to store all class elements
var boxes = document.getElementsByClassName('box'); 

// if the condition is true, output the code inside if block
if( boxes[0].textContent == '1' ) {
    console.log('Box[0] is a 1.');
}


// if the condition is true, output the code inside the if block
if( boxes[1].textContent == boxes[2].textContent ) {
    console.log('Box[1] and Box[2] are equivalent values.');
} else { // if the condition is false, output the code inside the else block
    console.log('Box[1] and Box[2] are not equivalent values.');   
}


if( boxes[0].textContent == '1' ) {   // if box[0] content is equivalent to 1
    console.log('Box[0] is equivalent to 1');
}                                   // if box[0] content is equivalent to 2
else if( boxes[0].textContent == '2' ) {
    console.log('Box[0] is equivalent to 2');
}
else {                              // if box[0] content is not equivalent to 1 or 2
    console.log('Box[0] is not equivalent to 1 or 2');
}

