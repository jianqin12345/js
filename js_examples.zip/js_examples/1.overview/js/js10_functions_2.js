/* S. Trowbridge 2019 */

/*
    If/Else

    If something is true do X, else do Y. This is where a program decides what code to run based upon a condition.

    Syntax:
    if(condition) { // this specifies what code to run if the condition is true
        some code;
    } else {        // this specifies what code to run if the condition is false
        some other code;
    }

    If/Else
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/if...else

*/

// assign the variable boxes to store all class elements
var boxes = document.getElementsByClassName('box'); 

function setColor() {
    var box = event.target;                         // the element associated with the event that trigged the function
    var text = event.target.textContent;            // the text content of the element

    if(text == 1) {                                 // if the content of the element is equal to 1, run the following code in the braces
        console.log( box.getAttribute('class') );   // print whatever classes are currently associated with the element box
        box.setAttribute('class', 'box red')        // change the class attribute of the box element (which classes are associated)
    } else {                                        // if the content of the element is NOT equal to 1, run the following code in the braces
        console.log( box.getAttribute('class') );   // print whatever classes are currently associated with the element box
        box.setAttribute('class', 'box green')      // change the class attribute of the box element (which classes are associated)       
    }
}

// add event listeners to call the setColor function whenever a box is clicked upon by the mouse
boxes[0].addEventListener('click', setColor);    
boxes[1].addEventListener('click', setColor); 
boxes[2].addEventListener('click', setColor); 
boxes[3].addEventListener('click', setColor); 
