/* S. Trowbridge 2019 */

/*
    Event

    An event is something that is triggered by the users interaction with the web page.

    Event Listeners

    An event listener waits and 'listens' for specific 'events' to occur before executing some code.

    Syntax:
    addEventListener('event_name', function_to_execute);

    Event Listener
    https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener

*/

// function to output element properties. this code only runs when a function call occurs
function printElement() {
    console.log(event.target);
    console.log(event.target.tagName);
    console.log(event.target.className);    
    console.log(event.target.id);   
    console.log(event.target.textContent);         
}

// add mouse click event listners for the specified elements 
document.getElementById('a').addEventListener('click', printElement);
document.getElementById('b').addEventListener('click', printElement);
document.getElementById('c').addEventListener('click', printElement);
document.getElementById('d').addEventListener('click', printElement);
