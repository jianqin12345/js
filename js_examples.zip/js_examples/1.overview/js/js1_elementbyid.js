/* S. Trowbridge 2019 */

/*
    Access by Id

    We can access an element by Id with the following syntax:
    document.getElementById('idname');

    We can access the text contents of an element by Id with the following syntax:
    document.getElementById('idname').textContent;

    JavaScript Guide
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

    JavaScript Console
    https://developer.mozilla.org/en-US/docs/Web/API/console

    getElementById
    https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementById

    textContent
    https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent
*/

// Output the HTML code for each element with the specified Id
console.log("Elements");
console.log(document.getElementById('a'));
console.log(document.getElementById('b'));
console.log(document.getElementById('c'));
console.log(document.getElementById('d'));

// Output the text content for each element with the specified Id
console.log("Element Contents");
console.log(document.getElementById('a').textContent);
console.log(document.getElementById('b').textContent);
console.log(document.getElementById('c').textContent);
console.log(document.getElementById('d').textContent);