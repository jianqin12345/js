/* S. Trowbridge 2019 */

/*
    Access by Tag

    Unlike Ids, built in HTML tags (<p>, <div>, <span>, etc.) are typically applied 
    to many elements (not just one). Consequently, when we access an HTML tag 
    from JavaScript we access all elements using this tag name in the order in which 
    they appear in the HTML document.

    Note that the first element is element 0 (zero indexing).

    Syntax:
    document.getElementsByTagName('tagname')[element #];

    Syntax:
    the first element   -  document.getElementsByTagName('tagname')[0];  
    the third element   -  document.getElementsByTagName('tagname')[2]; 

    We can access the HTMl content of a specified tag using innerHTML.
        
    JavaScript Guide
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

    getElementsByTagName
    https://developer.mozilla.org/en-US/docs/Web/API/Element/getElementsByTagName

    innerHTML
    https://developer.mozilla.org/en-US/docs/Web/API/Element/innerHTML

*/

// Output the HTML code each element with a 'div' tag
console.log("Elements");
console.log(document.getElementsByTagName('div')[0]);
console.log(document.getElementsByTagName('div')[1]);
console.log(document.getElementsByTagName('div')[2]);
console.log(document.getElementsByTagName('div')[3]);
console.log(document.getElementsByTagName('div')[4]);
console.log(document.getElementsByTagName('div')[5]);
console.log(document.getElementsByTagName('div')[6]);
console.log(document.getElementsByTagName('div')[7]);
console.log(document.getElementsByTagName('div')[8]);


// Output the HTML code stored within each element with a 'div' tag
console.log("Contents");
console.log(document.getElementsByTagName('div')[0].innerHTML);
console.log(document.getElementsByTagName('div')[1].innerHTML);
console.log(document.getElementsByTagName('div')[2].innerHTML);
console.log(document.getElementsByTagName('div')[3].innerHTML);
console.log(document.getElementsByTagName('div')[4].innerHTML);