/*  S. Trowbridge 2019

    Concatenate

    Concatenation is the "adding" of strings, to make larger strings.

    Syntax:
    var a = "Hi";
    var b = "There";
    var c = a + " " + b;    // c now stores "Hi There
*/

var screen = document.getElementById('screen');           // assign a variable to the screen of our inteface
var boxes = document.getElementsByClassName('box');       // assign boxes to the array of box class elements

var values = ['A', 'B', 'C', 'D'];                        // create an array of four values (same size as boxes)

function clearScreen() {                                  // create an array of four values (same size as boxes)
    document.getElementById('screen').textContent = "";   // clear the screen area (set it equal to a blank string)
    for(i=0; i<boxes.length; i++) {                       // set each box textcontent equal to 0
        boxes[i].textContent = values[i];
    }
    console.log("clearScreen()");
}
function nextLetter() {                                   // replace the value of the box with the next letter
    var box = event.target;                               // set the variable box to the box element
    if( box.textContent == 'A' ) {                        // if box text content is A    
        box.textContent = 'B';                            // set it to B
    }
    else if( box.textContent == 'B' ) {                   // if box text content is A     
        box.textContent = 'C';                            // set it to C
    }
    else if( box.textContent == 'C' ) {                   // if box text content is A       
        box.textContent = 'D';                            // set it to D
    }        
    else {                                                // if box content is not A B or C (in other words it is D)   
        box.textContent = 'A';                            // set it back to A 
    }
    console.log("nextLetter()");
}
function updateScreen() {                                 // update the screen with a "concatenated" string of all boxes
    var s = "";                                           // set the variable s to a blank string
    for(i=0; i<boxes.length; i++) {                       // iterate through all boxes
        s = s + boxes[i].textContent;                     // "add" the textContent of the current box to the string s (repeat for all boxes)
    }
    screen.textContent = s;                               // update the screen content to display the string s
    console.log("updateScreen()");
}

for(i=0; i<boxes.length; i++) {                           // iterate from 0 to 3
    boxes[i].textContent = values[i];                     // populate each box with a value from the data array
    boxes[i].addEventListener('click', nextLetter);       // add an click event listener to advance by a letter  
    boxes[i].addEventListener('click', updateScreen);     // add an click event listener for each box that calls incVal    
}
screen.addEventListener('click', clearScreen);            // add a listener to clear screen if it is cliedk upon
updateScreen();                                           // call the updateScreen function when the document loads

