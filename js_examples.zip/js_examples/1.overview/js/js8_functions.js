/* S. Trowbridge 2019 */

/*
    Functions

    A function is a grouped set of statements that performs a specific task. 
    Functions must be 'called' for the code inside the function to be executed.

    Syntax for a function named f1:
    function f1() {
        one or more lines of code to execute;
    }

    Parameters

    A parameter is an input value for a function.

    Syntax for a function named f2 with two input parameters:
    function f2(p1, p2, etc.) {
        console.log(p1);        // this would output the item p1
    }

    Function Call

    The command to execute the group of commands known as a function.

    Syntax:
    f1();              // call f1 without parameters
    f2(a, b);          // call f2 with two input values a and b (which are copied to p1 and p2)

    Functions
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions
*/

// ************************************************************************* //
// code that is executed only when a function is called by name

function hello() {              // function that prints the world hello
    console.log('Hello World');
}
function printElement(e) {      // function that prints values of the input parameter named e
    console.log(e);
    console.log(e.textContent);               
}

// ************************************************************************* //
// code that is executed when the page is loaded

// call the hello function
hello(); 

// call the printElement function with each element as an input parameter
printElement( document.getElementById('a') );
printElement( document.getElementById('b') );
printElement( document.getElementById('c') );
printElement( document.getElementById('d') );
