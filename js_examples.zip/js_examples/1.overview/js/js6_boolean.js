/* S. Trowbridge 2019 */

/*
    Boolean Conditions

    Statements that result in true or false values.

    Equality Operator ==
    Given the expression a == b, this resolves to true if the value of a is equivalent to the value of b.
    Otherwise it resolves to false.

    Inequality Operator !=
    Given the expression a != b, this resolves to false if the value of a is equivalent to the value of b.
    Otherwise it resolves to true.

    Greater than, Less Than, Greater than or equal to, Less than or equal to (> < >= <=)
    All resolve to true or false.

    Boolean
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean

    Comparison Operators
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Comparison_Operators

*/

// assign the variable boxes to store all class elements
var boxes = document.getElementsByClassName('box'); 

console.log("Equality");

// boolean conditions testing equality (resolve to true or false)
console.log( boxes[0].textContent == 1 );
console.log( boxes[1].textContent == 1 );
console.log( boxes[2].textContent == 1 );
console.log( boxes[3].textContent == 1 );

console.log(" ");
console.log("Inequality");

// boolean conditions testing inequality (resolve to true or false)
console.log( boxes[0].textContent != 1 );
console.log( boxes[1].textContent != 1 );
console.log( boxes[2].textContent != 1 );
console.log( boxes[3].textContent != 1 );

console.log(" ");
console.log("Greater/Less Than");

// boolean conditions testing greater than or less than (resolve to true or false)
console.log( boxes[0].textContent < 1 );
console.log( boxes[1].textContent < 1 );
console.log( boxes[2].textContent > 1 );
console.log( boxes[3].textContent > 1 );

console.log(" ");
console.log("Greater/Less Than OR Equal to");

// boolean conditions testing greater/less than or equal to (resolve to true or false)
console.log( boxes[0].textContent <= 1 );
console.log( boxes[1].textContent <= 1 );
console.log( boxes[2].textContent >= 1 );
console.log( boxes[3].textContent >= 1 );


