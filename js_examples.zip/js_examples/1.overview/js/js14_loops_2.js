/* S. Trowbridge 2019 */

/*
    Loop

    A loop is used to repeat one or more statements of code as long as a specified condition is true.

    Syntax to create an array:
    while(i<10) {           // repeat the code in the braces {...} as long as i is less than 10
        run some code;
    }
    for(i=0;i<10; i=i+1) {  // repeat the code in the braces {...} as long as i is less than 10
        run some code;
    }

    Loops
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Loops_and_iteration

*/
                
// boxes is an "array" of box elements, divs is an array of div elements
var boxes = document.getElementsByClassName('box');
var dives = document.getElementsByTagName('div');    

// create various arrays
var numbers  = [1, 2, 3, 4, 5, 6, 7, 8, 9];  
var letters = ['A', 'B', 'C', 'D', 'E', 'F'];
var symbols = ['!', '@', '#']; 
var categories = ['letters','numbers','symbols', 'sizes']; 
                
// assign each box to an array value from the array categories
for(i=0;i<boxes.length; i++) {
    boxes[i].textContent = categories[i];
}

// functions which output the values of three different arrays
function printNumbers() {
    for(i=0; i<numbers.length; i++) {
        console.log(numbers[i]);
    }
    console.log("");            
}
function printLetters() {
    for(i=0; i<letters.length; i++) {
        console.log(letters[i]);
    }
    console.log("");             
}
function printSymbols() {
    for(i=0; i<symbols.length; i++) {
        console.log(symbols[i]);
    }
    console.log("");   
}
function printSizes() {
    console.log(numbers.length);
    console.log(letters.length);
    console.log(symbols.length);        
}

// assign a listener to call a different function for each button
boxes[0].addEventListener('click', printNumbers);
boxes[1].addEventListener('click', printLetters);
boxes[2].addEventListener('click', printSymbols);
boxes[3].addEventListener('click', printSizes);

