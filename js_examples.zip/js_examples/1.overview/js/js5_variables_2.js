/* S. Trowbridge 2019 */

/*
    Variables
    Variables store information which can be retrieved for later use.

    Syntax:
    var variablename = data_to_store;

    JavaScript Guide
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

    Variable
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/var
*/

// store all elements of a class into a variable (multiple elements)
var boxes = document.getElementsByClassName('box');

// output the individual elements of the class box
console.log(boxes[0]);
console.log(boxes[1]);
console.log(boxes[2].textContent);
console.log(boxes[3].textContent);

// The following lines modify the original content from the HTML file
boxes[2].textContent = 'Y';
boxes[3].textContent = 'Z';

// Directly accessing the elements will output the updated value.
console.log(boxes[2].textContent);
console.log(boxes[3].textContent);

