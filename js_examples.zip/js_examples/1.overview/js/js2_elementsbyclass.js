/* S. Trowbridge 2019 */

/*
    Access by Class

    Unlike Ids, classes are typically applied to many elements (not just one).
    Consequently, when we access an HTML tag from JavaScript we access all elements
    using this tag name in the order in which they appear in the HTML document.

    Note that the first element is element 0 (zero indexing).
    
    Syntax:
    document.getElementsByClassName('classname')[element #];

    Syntax:
    the first element   -  document.getElementsByClassName('classname')[0];  
    the third element   -  document.getElementsByClassName('classname')[2]; 

    JavaScript Guide
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

    getElementsByClassName
    https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementsByClassName

    textContent
    https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent

*/

// Output the HTML code of each element with a class attribute 'box' 
console.log("Elements");
console.log(document.getElementsByClassName('box')[0]);
console.log(document.getElementsByClassName('box')[1]);
console.log(document.getElementsByClassName('box')[2]);
console.log(document.getElementsByClassName('box')[3]);


// Output the HTML code stored inside each elements with a class attribute 'box' 
console.log("Element Contents");
console.log(document.getElementsByClassName('box')[0].textContent);
console.log(document.getElementsByClassName('box')[1].textContent);
console.log(document.getElementsByClassName('box')[2].textContent);
console.log(document.getElementsByClassName('box')[3].textContent);
