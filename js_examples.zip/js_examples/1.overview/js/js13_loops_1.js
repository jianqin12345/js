/* S. Trowbridge 2019 */

/*
    Loop

    A loop is used to repeat one or more statements of code as long as a specified condition is true.

    Syntax to create an array:
    while(i<10) {           // repeat the code in the braces {...} as long as i is less than 10
        run some code;
    }
    for(i=0;i<10; i=i+1) {  // repeat the code in the braces {...} as long as i is less than 10
        run some code;
    }

    Loops
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Loops_and_iteration

*/
                
// while loop
console.log("\nWhile:");      // output a newline followed by text

var i = 0;                  // set a variable i equivalent to 0
while(i<4) {                // while the statement i<4 is true, repeatedly execute the code inside the braces {...}
    console.log(i);         // output the current value of i everytime the loop repeats
    i=i+1;                  // increment i by 1 every time the loop repeats
}

console.log("\nFor:");      // output a newline followed by text

// for loop                 // count from 0 to 4
for(i=0; i<5; i=i+1) {     // set i equal to 0, repeat as long as i<10, every time loop runs, increment i by 1
    console.log(i);         // output the value of i every time the loop repeats
}

console.log("\ni++:");      // output a newline followed by text

// ++ operator (increment i by 1)
for(i=0; i<10; i++) {        // count from 0 to 9
    console.log(i);
}
