var player =1;
var numbox = document.getElementsByClassName('box');
var winner = 0;
var player1 = document.getElementById('b1');
var player2 = document.getElementById('b2');

var data = [0,0,0,0,0,0,0,0,0];



function clkbox (){
    var e = event.target;
    var index = Array.from(numbox).indexOf(e);
    console.log(index);
        if (player == 1 && e.textContent ==""){
            e.textContent = "X";
            e.setAttribute('class', 'box green');
            data[index] = 1;
            player =2;
        
            
        }
        else if (player ==2 && e.textContent ==""){
            e.textContent= "O";
           player =1;   
            e.setAttribute('class', 'box yellow');
            data[index] = -1;
            
        
    
        }
        console.log(index);
    checkwinner();
    
}
    function checkwinner(){
        var sum = data[0] + data [1] + data [2];
        if( sum ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=0 & i!=1 &i!=2){
                    numbox[i].setAttribute('class', "box black");
                    }
                }
            }
        else if (sum ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
                if(i!=0 & i!=1 &i!=2){
                    numbox[i].setAttribute('class', "box black");
                    }
            }
          } 

        var sum1 = data[3] + data[4] + data[5];
        if( sum1 ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=3 & i!=4 &i!=5){
                    numbox[i].setAttribute('class', "box black");
                    }
                }
            }
        else if (sum1 ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
                if(i!=3 & i!=4 &i!=5){
                    numbox[i].setAttribute('class', "box black");
                    }
            }
          } 

          var sum2 = data[6] + data[7] + data[8];
          if( sum2 ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=6 & i!=7 &i!=8){
                    numbox[i].setAttribute('class', "box black");
                    }
                }
            }
        else if (sum2 ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
                if(i!=6 & i!=7 &i!=8){
                    numbox[i].setAttribute('class', "box black");
                    }
            }
          } 

          var sum4 = data[0] + data[3] +data[6];
          if( sum4 ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=0 & i!=3 &i!=6){
                    numbox[i].setAttribute('class', "box black");
                    }
                }
            }
        else if (sum4 ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
                if(i!=0 & i!=3 &i!=6){
                    numbox[i].setAttribute('class', "box black");
                    }
            }
          }

          var sum5 = data[1] + data[4] +data[7];
          if( sum5 ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=1 & i!=4 &i!=7){
                    numbox[i].setAttribute('class', "box black");
                    }
                }
            }
        else if (sum5 ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
                if(i!=1 & i!=4 &i!=7){
                    numbox[i].setAttribute('class', "box black");
                    }
            }
          }

          var sum6 = data[2] + data[5] +data[8];
          if( sum6 ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=2 & i!=5 &i!=8){
                    numbox[i].setAttribute('class', "box black");
                    }
                }
            }
        else if (sum6 ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
                if(i!=2 & i!=5 &i!=8){
                    numbox[i].setAttribute('class', "box black");
                    }
            }
          }

          var sum7 = data[0] + data[4] +data[8];
         if( sum7 ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=0 & i!=4 &i!=8){
            numbox[i].setAttribute('class', "box black");
            }
        }
    }
        else if (sum7 ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
            if(i!=0 & i!=4 &i!=8){
            numbox[i].setAttribute('class', "box black");
            }
    }
  }

          var sum8 = data[2] + data[4] +data[6];
          if( sum8 ==3 ){
            winner = 1;
            console.log(winner);
            for(i=0;i<numbox.length;i++){
                if(i!=2 & i!=4 &i!=6){
                    numbox[i].setAttribute('class', "box black");
                    }
                }
            }
        else if (sum8 ==-3){
            winner = 2;
            for(i=0;i<numbox.length;i++){
                if(i!=2 & i!=4 &i!=6){
                    numbox[i].setAttribute('class', "box black");
                    }
            }
          }
          for(i=0;i<numbox.length;i++){
          if(winner==0 && data[0] !=0 && data[1] !=0 && data[2] !=0 && data[3] !=0 && data[4] !=0 && data[5] !=0 && data[6] !=0 && data[7] !=0 && data[8] !=0)  {
            numbox[i].setAttribute('class', "box black");
          }
        }
          if(winner ==1){
              player1.textContent = parseFloat(player1.textContent) +1;
              player =null;
              for(i=0;i<numbox.length;i++){
                  data[i]=0;
              }
              winner=3;
          }
          else if (winner ==2){
             player2.textContent = parseFloat(player2.textContent) +1;
             player = null;
             for(i=0;i<numbox.length;i++){
                data[i]=0;
            }
            winner=3;
           
          }
                 
          
        }

    function reset(){
            winner = 0;
            for(i=0; i<numbox.length; i++){
                numbox[i].setAttribute('class', 'box');
                numbox[i].textContent="";
                data[i]=0;
            }
           
            player = 1;
            console.log('reset');
        }

for(i=0; i<numbox.length; i++){
    numbox[i].addEventListener('click',clkbox);
}
document.getElementById('tp').addEventListener('click',reset);


